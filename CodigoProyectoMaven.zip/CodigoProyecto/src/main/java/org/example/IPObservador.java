package org.example;

public interface IPObservador {
}
