package org.example;


public enum TAccion {
    MotorBidireccional,AperturaCierre,Termorregulador;
}
