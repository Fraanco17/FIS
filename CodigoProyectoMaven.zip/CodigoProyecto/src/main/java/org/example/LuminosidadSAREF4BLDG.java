package org.example;


public class LuminosidadSAREF4BLDG extends Sensores{

    public LuminosidadSAREF4BLDG(String fabricante, Integer numSerie, Integer fecha, String usuario) {
        super(fabricante, numSerie, fecha, usuario);
    }
}