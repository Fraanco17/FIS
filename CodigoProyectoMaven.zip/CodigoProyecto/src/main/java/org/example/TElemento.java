package org.example;


public enum TElemento {
    Techo,Pared;
}
